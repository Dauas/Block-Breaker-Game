﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour {

    public bool autoplay;
    private Ball ball;
    private Vector3 paddlePos = new Vector3(0f, 0.5f, -2f);

    // Use this for initialization
    void Start () {
        ball = GameObject.FindObjectOfType<Ball>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!autoplay)
        {
            MoveWithMouse();
        }
        else
        {
            Autoplay();
        }
	}

    void MoveWithMouse()
    {
        float mousePosUnits = Input.mousePosition.x / Screen.width * 16;
        paddlePos.x = Mathf.Clamp(mousePosUnits, .5f, 15.5f);
        this.transform.position = paddlePos;
    }

    void Autoplay()
    {
        paddlePos.x = ball.transform.position.x;
        this.transform.position = paddlePos;
    }
}
