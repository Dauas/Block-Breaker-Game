﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score : MonoBehaviour {

    private Player player;
    //public GUIText text;
	// Use this for initialization
	void Start () {
        //text = gameObject.GetComponent<GUIText>;
        //this.text = "" + Player.score;
        player = GameObject.FindObjectOfType<Player>();
        player.DisplayScore();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    
}
