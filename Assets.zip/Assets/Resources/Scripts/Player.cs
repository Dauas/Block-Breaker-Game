﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public static int lives;
    public static int score;
    static Player instance = null;
    private List<GameObject> Lives;
    public GameObject life = null;
    private float time;

    // Use this for initialization
    private void Start()
    {
        if (instance != null)
        {
            Destroy(gameObject);
            print("Duplicate gameObject Self-Destructing");
        }
        else
        {
            instance = this;
            GameObject.DontDestroyOnLoad(gameObject);

        }
        ChangeLives();
    }

    public void NewGame()
    {
        time = 0;
        ChangeLives();
    }

    // Update is called once per frame
    void Update () {
        time += Time.deltaTime;
	}

    public void ChangeLives()
    {
        ResetLives();
    }

    /** Old Code
    private void DrawLives()
    {
        int i = 0;
        foreach (GameObject life in Lives)
        {
            life.transform.position = new Vector2(14.5f - i, 11.5f);
            i++;
        }
    }
    **/

    private void ResetLives()
    {
        print(time);
        Life[] allChildren = GetComponentsInChildren<Life>();
        foreach (Life child in allChildren)
        {
            child.DestroyMe();
        }
            for (int i = 0; i < lives; i++)
            {
                Vector3 lifeTrans = new Vector3(14.5f - i, 11f, -9);
                Instantiate(life, lifeTrans, Quaternion.identity, gameObject.transform);
            }
    }

    public void SetScore()
    {
        Player.score = 1000 - (int)(time * 2);
        DisplayScore();
    }

    public void DisplayScore()
    {
        //Score scoreText = FindObjectOfType<Score>();
        //scoreText.text.text = "" + Player.score; 
        GUIText guiText = GameObject.FindGameObjectWithTag("Score").GetComponent<GUIText>();
        guiText.text = "" + score;

    }
}
