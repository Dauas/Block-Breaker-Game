﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick : MonoBehaviour {

    public int maxHits;
    private int timesHit;
    private LevelManager levelManager;
    private SpriteRenderer spriteRenderer;
    public static int brickCount = 0;
    private bool isBreakable;

    // Use this for initialization
    void Start () {
        levelManager = FindObjectOfType<LevelManager>();
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        timesHit = 0;
        determineColor();
        isBreakable = (this.tag == "Breakable");
        if (isBreakable)
        {
            brickCount++;
        }
    }
	
	// Update is called once per frame
	void Update () {


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isBreakable)
        {
            handleHits();
        }

    }

    private void handleHits()
    {
        timesHit++;
        if (timesHit < maxHits) { }
        else
        {
            brickCount--;
            levelManager.BrickDestroyed();
            Destroy(gameObject);
        }
        determineColor();
    }

    private void determineColor()
    {
        int colorInt = maxHits - timesHit;
        float r = 0;
        float g = 0;
        float b = 0;
        switch (colorInt)
        {
            case 0:
                r = 0.58f;
                b = 1f;
                break;

            case 1:
                r = 1f;
                break;

            case 2:
                r = 1f;
                g = 1f;
                break;

            case 3:
                g = 1f; 
                break;

            default:
                r = 1f;
                g = 1f;
                b = 1f;
                break;
        }

        spriteRenderer.color = new Color(r, g, b);

    }

    void SimulateWin()
    {
        levelManager.LoadNextLevel();
    }
}
