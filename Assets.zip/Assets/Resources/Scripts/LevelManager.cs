﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour {

    public Player player;

	// Use this for initialization
	void Start () {
        player = FindObjectOfType<Player>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void LoadLevel(string name)
    {
        //Debug.Log("Level load requested for: " + name);
        Application.LoadLevel(name);
        if (Brick.brickCount > 0) { Brick.brickCount = 0; }
    }

    public void QuitRequest(bool canQuit)
    {
        //Debug.Log("I want to Quit");
        if (canQuit)
        {
            //Debug.Log("Quiting");
            Application.Quit();
        }
        else
        {
            //Debug.Log("Quit Denied");
        }

    }

    public void LoadNextLevel()
    {
        Application.LoadLevel(Application.loadedLevel + 1);
        player.SetScore();
    }

    public void BrickDestroyed()
    {
        if (Brick.brickCount <= 0)
        {
            LoadNextLevel();
        }
    }

    public void StartGame()
    {
        Player.lives = 3;
        LoadLevel("level_01");
        player.NewGame();
    }


}
