﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {

    private Paddle paddle;

    private Rigidbody2D rigidBody;

    private Vector3 paddleToBallVector;

    private AudioSource audioSource;

    private bool holding = true;

    public float maxSpeed = 15f;

	// Use this for initialization
	void Start () {
        paddle = GameObject.FindObjectOfType<Paddle>();
        paddleToBallVector = this.transform.position - paddle.transform.position;
        rigidBody = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update() {
        if (holding)
        {
            this.transform.position = paddle.transform.position + paddleToBallVector;
     
            if (Input.GetMouseButtonDown(0))
            {
                holding = false;
                this.rigidBody.velocity = new Vector2(0f, 10f);
            }
        }
        if (rigidBody.velocity.magnitude >= maxSpeed)
        {
            this.rigidBody.velocity += new Vector2(this.rigidBody.velocity.x / -15, this.rigidBody.velocity.y / -15); 
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        audioSource.Play();
        Vector2 tweak = new Vector2(0, 0);
        if (collision.collider.tag == "Paddle")
        {
            float x = gameObject.transform.position.x - collision.collider.transform.position.x;
            float y;
            if (x == 0)
            {
                y = 2f;
            }
            else
            {
                y = (float)(4 * Mathf.Abs(x));
            }
            tweak = new Vector2(x*5, y);
        }
        else
        {
            tweak = new Vector2(Random.Range(-0.2f, 0.2f), 0);
        }
        this.rigidBody.velocity += tweak;
    }

    public void ResetBall()
    {
        holding = true;
    }
}
