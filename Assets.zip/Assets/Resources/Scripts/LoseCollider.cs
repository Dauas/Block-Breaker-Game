﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoseCollider : MonoBehaviour {

    private LevelManager levelManager;
    private Paddle paddle;
    private Ball ball;
    private Player player;


    private void Start()
    {
        levelManager = FindObjectOfType<LevelManager>();
        paddle = FindObjectOfType<Paddle>();
        ball = FindObjectOfType<Ball>();
        player = FindObjectOfType<Player>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Player.lives <= 0)
        {
            levelManager.LoadLevel("Lose_Screen");
        } else
        {
            ResetLevel();
        }
    }

    public void ResetLevel()
    {
        Player.lives--;
        ball.ResetBall();
        player.ChangeLives();
    }
}
